
// MVMul_data_generatorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MVMul_data_generator.h"
#include "MVMul_data_generatorDlg.h"
#include "afxdialogex.h"
#include <time.h>
#include <sys/stat.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

///< Macro for memory free and assign null value
#define FREE_MEM(pointer)\
if (NULL != pointer)\
	{\
	free(pointer); \
	pointer = NULL; \
	}

#define SUCCESS						0
#define CANNOT_OPEN_FILE			10
#define MISS_MATCH_ORDER			11

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CMVMul_data_generatorDlg dialog



CMVMul_data_generatorDlg::CMVMul_data_generatorDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMVMul_data_generatorDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMVMul_data_generatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_MSG, m_listMsg);
}

BEGIN_MESSAGE_MAP(CMVMul_data_generatorDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_GENERATE, &CMVMul_data_generatorDlg::OnBnClickedButtonGenerate)
	ON_BN_CLICKED(IDC_BUTTON_M_INPUT_GET, &CMVMul_data_generatorDlg::OnBnClickedButtonMInputGet)
	ON_BN_CLICKED(IDC_BUTTON_V_INPUT_GET, &CMVMul_data_generatorDlg::OnBnClickedButtonVInputGet)
	ON_BN_CLICKED(IDC_BUTTON_MVMUL, &CMVMul_data_generatorDlg::OnBnClickedButtonMvmul)
	ON_WM_NCDESTROY()
	ON_BN_CLICKED(IDC_BUTTON_AUDIT_GET, &CMVMul_data_generatorDlg::OnBnClickedButtonAuditGet)
	ON_BN_CLICKED(IDC_BUTTON_TARGET_GET, &CMVMul_data_generatorDlg::OnBnClickedButtonTargetGet)
	ON_BN_CLICKED(IDC_BUTTON_RESULT_AUDIT, &CMVMul_data_generatorDlg::OnBnClickedButtonResultAudit)
END_MESSAGE_MAP()


// CMVMul_data_generatorDlg message handlers

BOOL CMVMul_data_generatorDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	CEdit		*pMRSize = (CEdit*)GetDlgItem(IDC_EDIT_MR_SIZE);
	CEdit		*pMCSize = (CEdit*)GetDlgItem(IDC_EDIT_MC_SIZE);
	CEdit		*pMName = (CEdit*)GetDlgItem(IDC_EDIT_M_FILE_NAME);
	CEdit		*pVName = (CEdit*)GetDlgItem(IDC_EDIT_V_FILE_NAME);
	CEdit		*pMInput = (CEdit*)GetDlgItem(IDC_EDIT_M_INPUT);
	CEdit		*pVInput = (CEdit*)GetDlgItem(IDC_EDIT_V_INPUT);

	if (NULL != pMRSize)
		pMRSize->SetWindowTextW(L"2000");

	if (NULL != pMCSize)
		pMCSize->SetWindowTextW(L"100");

	if (NULL != pMName)
		pMName->SetWindowTextW(L"matrix.dat");

	if (NULL != pVName)
		pVName->SetWindowTextW(L"vector_input.dat");

	if (NULL != pMInput)
		pMInput->SetWindowTextW(L"matrix.dat");

	if (NULL != pVInput)
		pVInput->SetWindowTextW(L"vector_input.dat");

	m_strMPath = L"matrix.dat";
	m_strVPath = L"vector_input.dat";

	m_Matrix.fRowCount = 0;
	m_Matrix.fColumnCount = 0;
	m_Matrix.pfColumn = NULL;
	m_Matrix.pfImaginary = NULL;
	m_Matrix.pfReal = NULL;
	m_Matrix.pfRow = NULL;

	m_Vector.fRowCount = 0;
	m_Vector.pfImaginary = NULL;
	m_Vector.pfReal = NULL;

	m_VectorResult.fRowCount = 0;
	m_VectorResult.pfImaginary = NULL;
	m_VectorResult.pfReal = NULL;

	m_VectorAudit.fRowCount = 0;
	m_VectorAudit.pfImaginary = NULL;
	m_VectorAudit.pfReal = NULL;

	m_VectorAuditTarget.fRowCount = 0;
	m_VectorAuditTarget.pfImaginary = NULL;
	m_VectorAuditTarget.pfReal = NULL;

	AddMsg(L"Variables intialized.");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMVMul_data_generatorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMVMul_data_generatorDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMVMul_data_generatorDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CMVMul_data_generatorDlg::OnBnClickedButtonGenerate()
{
	// TODO: Add your control notification handler code here
	CEdit			*pMRSize = (CEdit*)GetDlgItem(IDC_EDIT_MR_SIZE);
	CEdit			*pMCSize = (CEdit*)GetDlgItem(IDC_EDIT_MC_SIZE);
	CEdit			*pMName = (CEdit*)GetDlgItem(IDC_EDIT_M_FILE_NAME);
	CEdit			*pVName = (CEdit*)GetDlgItem(IDC_EDIT_V_FILE_NAME);
	CButton			*pMisMatch = (CButton*)GetDlgItem(IDC_CHECK_MISMATCH);
	CButton			*pMissing = (CButton*)GetDlgItem(IDC_CHECK_MISSING_ELEMENT);
	CString			strTemp, strMatrixFileName = L"matrix.dat", strVectorFileName = L"vector_input.dat";
	double			fRowSize = 2000, fColumnSize = 100;
	BOOL			bMisMatch = FALSE, bMissing = FALSE;
	CWaitCursor		wait;
	CString			strMsg;

	AddMsg(L"Generating Matrix and Vector.");
	USES_CONVERSION;
	if (NULL != pMRSize)
	{
		pMRSize->GetWindowTextW(strTemp);
		fRowSize = atof(OLE2A(strTemp.GetBuffer()));
		strTemp.ReleaseBuffer();
	}

	if (NULL != pMCSize)
	{
		pMCSize->GetWindowTextW(strTemp);
		fColumnSize = atof(OLE2A(strTemp.GetBuffer()));
		strTemp.ReleaseBuffer();
	}

	if (NULL != pMName)
		pMName->GetWindowTextW(strMatrixFileName);

	if (NULL != pVName)
		pVName->GetWindowTextW(strVectorFileName);

	if (NULL != pMisMatch)
		if (BST_CHECKED == pMisMatch->GetCheck())
			bMisMatch = TRUE;

	if (NULL != pMissing)
		if (BST_CHECKED == pMissing->GetCheck())
			bMissing = TRUE;

	strMsg.Format(L"Matrix: %d by %d, Vector: %d", (int)fRowSize, (int)fColumnSize, (int)fRowSize);
	AddMsg(strMsg);

	srand(time(NULL));
	GenerateMatrix(fRowSize, fColumnSize, strMatrixFileName, bMissing);
	AddMsg(L"Matrix was generated.");
	if (bMisMatch)
		fColumnSize -= (rand() % (int)fColumnSize);
	GenerateVector(fColumnSize, strVectorFileName, bMissing);
	AddMsg(L"Vector was generated.");
	AddMsg(L"Generated completed!");
	MessageBox(L"Generated completed!");
}

#define WRITE_BUFFER_SIZE			32000

void CMVMul_data_generatorDlg::GenerateMatrix(double fRowSize, double fColumnSize, CString strMatrixFileName, BOOL bMissing)
{
	CFile				dataFile;
	double				i, j, temp;
	int					temp1, temp2;
	double				fBuffer[WRITE_BUFFER_SIZE];
	int					nBuferIndex, nValidIndex;

	if (!dataFile.Open(strMatrixFileName, CFile::modeCreate | CFile::modeWrite))
	{
		MessageBox(L"Can't create matrix file.");
		return;
	}

	nBuferIndex = 0;
	nValidIndex = 0;
	for (i = 0; i < fRowSize; ++i)
	{
		for (j = 0; j < fColumnSize; ++j)
		{
			temp1 = rand();
			if (temp1 % 500 == 0 && true == bMissing)
				continue;

			//dataFile.Write(&i, sizeof(double));
			//dataFile.Write(&j, sizeof(double));
			fBuffer[nBuferIndex++] = i;
			fBuffer[nBuferIndex++] = j;
			
			temp2 = rand();
			if ( 0 != temp2)
				temp = (double)temp1 / (double)temp2;
			else
				temp = (double)temp1;
			//dataFile.Write(&temp, sizeof(double));
			fBuffer[nBuferIndex++] = temp;
			temp1 = rand();
			temp2 = rand();
			if (0 != temp2)
				temp = (double)temp1 / (double)temp2;
			else
				temp = (double)temp1;
			//dataFile.Write(&temp, sizeof(double));
			fBuffer[nBuferIndex++] = temp;

			if (WRITE_BUFFER_SIZE / sizeof(double) == nBuferIndex)
			{
				dataFile.Write(fBuffer, WRITE_BUFFER_SIZE);
				nBuferIndex = 0;
			}
		}
	}

	if ( 0 != nBuferIndex)
		dataFile.Write(fBuffer, nBuferIndex * sizeof(double));

	dataFile.Close();
}


void CMVMul_data_generatorDlg::GenerateVector(double fRowSize, CString strVectorFileName, BOOL bMissing)
{
	CFile				dataFile;
	double				i, temp;
	int					temp1, temp2;

	if (!dataFile.Open(strVectorFileName, CFile::modeCreate | CFile::modeWrite))
	{
		MessageBox(L"Can't create vector file.");
		return;
	}

	for (i = 0; i < fRowSize; ++i)
	{
		temp1 = rand();
		temp2 = rand();
		if (0 != temp2)
			temp = (double)temp1 / (double)temp2;
		else
			temp = (double)temp1;
		dataFile.Write(&temp, sizeof(double));
		temp1 = rand();
		temp2 = rand();
		if (0 != temp2)
			temp = (double)temp1 / (double)temp2;
		else
			temp = (double)temp1;
		dataFile.Write(&temp, sizeof(double));
	}

	dataFile.Close();
}

void CMVMul_data_generatorDlg::InitAuditData()
{
	m_VectorAudit.fRowCount = 0;
	FREE_MEM(m_VectorAudit.pfReal);
	FREE_MEM(m_VectorAudit.pfImaginary);

	m_VectorAuditTarget.fRowCount = 0;
	FREE_MEM(m_VectorAuditTarget.pfReal);
	FREE_MEM(m_VectorAuditTarget.pfImaginary);
}

void CMVMul_data_generatorDlg::InitData()
{
	m_Matrix.fColumnCount = 0;
	m_Matrix.fRowCount = 0;

	FREE_MEM(m_Matrix.pfColumn);
	FREE_MEM(m_Matrix.pfImaginary);
	FREE_MEM(m_Matrix.pfReal);
	FREE_MEM(m_Matrix.pfRow);

	m_Vector.fRowCount = 0;
	FREE_MEM(m_Vector.pfImaginary);
	FREE_MEM(m_Vector.pfReal);

	m_VectorResult.fRowCount = 0;
	FREE_MEM(m_VectorResult.pfImaginary);
	FREE_MEM(m_VectorResult.pfReal);

	m_VectorAudit.fRowCount = 0;
	FREE_MEM(m_VectorAudit.pfImaginary);
	FREE_MEM(m_VectorAudit.pfReal);
}


void CMVMul_data_generatorDlg::OnBnClickedButtonMInputGet()
{

	TCHAR szFilters[] = _T("Data File (*.dat)|*.dat|All Files (*.*)|*.*||");

	CFileDialog fileDlg(TRUE, _T("dat"), _T("*.dat"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (fileDlg.DoModal() == IDOK)
	{
		m_strMPath = fileDlg.GetPathName();

		// Implement opening and reading file in here.

		//Change the window's title to the opened file's title.
		CString fileName = fileDlg.GetFileName();

		CEdit			*pMInput = (CEdit*)GetDlgItem(IDC_EDIT_M_INPUT);

		pMInput->SetWindowText(fileName);
		m_strMsg.Format(L"Matirx file: %s", fileName);
		AddMsg(m_strMsg);
	}
}


void CMVMul_data_generatorDlg::OnBnClickedButtonVInputGet()
{
	TCHAR szFilters[] = _T("Data File (*.dat)|*.dat|All Files (*.*)|*.*||");

	CFileDialog fileDlg(TRUE, _T("dat"), _T("*.dat"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (fileDlg.DoModal() == IDOK)
	{
		m_strVPath = fileDlg.GetPathName();

		// Implement opening and reading file in here.

		//Change the window's title to the opened file's title.
		CString fileName = fileDlg.GetFileName();

		CEdit			*pVInput = (CEdit*)GetDlgItem(IDC_EDIT_V_INPUT);

		pVInput->SetWindowText(fileName);
		m_strMsg.Format(L"Vector file: %s", fileName);
		AddMsg(m_strMsg);
	}
}


void CMVMul_data_generatorDlg::OnBnClickedButtonMvmul()
{
	// TODO: Add your control notification handler code here
	if (m_strMPath.IsEmpty() || m_strVPath.IsEmpty())
	{
		MessageBox(L"Select data file first!", L"No data file", MB_ICONSTOP);
		return;
	}

	clock_t				load_start_time, load_end_time;
	clock_t				calcu_start_time, calcu_end_time;
	int					nRtn;
	CWaitCursor			wait;
	CString				strError;

	load_start_time = clock();
	InitData();

	nRtn = CountVectorSize();
	if (CANNOT_OPEN_FILE == nRtn)
	{
		wait.Restore();
		MessageBox(L"Can't open vector file", L"Can't calculating", MB_ICONSTOP);
		return;
	}

	nRtn = CountMatrixSize();
	if (MISS_MATCH_ORDER == nRtn)
		strError = L"Vector doesn't have same size with Matrix";
	else if (CANNOT_OPEN_FILE == nRtn)
		strError = L"Can't open matrix file";

	if ( SUCCESS != nRtn )
	{
		wait.Restore();
		MessageBox(strError, L"Can't calculating", MB_ICONSTOP);
		return;
	}

	if (m_Matrix.fColumnCount != m_Vector.fRowCount)
	{
		wait.Restore();
		MessageBox(L"Vector doesn't have same size with Matrix", L"Can't calculating", MB_ICONSTOP);
		return;
	}

	if (!LoadData())
	{
		wait.Restore();
		MessageBox(L"Can't load data file", L"Can't load", MB_ICONSTOP);
		return;
	}

	load_end_time = clock();
	m_strMsg.Format(L"Data load %f sec taken", ((double)(load_end_time - load_start_time)) / CLOCKS_PER_SEC);
	AddMsg(m_strMsg);

	calcu_start_time = clock();
	if (MVMul(&m_VectorResult))
	{
		calcu_end_time = clock();
		wait.Restore();
		m_strMsg.Format(L"MVMul %f sec taken", ((double)(calcu_end_time - calcu_start_time)) / CLOCKS_PER_SEC);
		AddMsg(m_strMsg);
		AddMsg(L"Calculating finished");
		MessageBox(L"Calculating finished", L"Completed", MB_ICONINFORMATION);
	}
}

int CMVMul_data_generatorDlg::CountMatrixSize()
{
	FILE				*matrix;
	long long			file_size;
	int					nRtn = SUCCESS;
	struct stat			buf;

	USES_CONVERSION;
	if (NULL != (matrix = fopen(OLE2A(m_strMPath), "rb")))
	{
		fseek(matrix, 0, SEEK_END);
		file_size = ftell(matrix);

		m_Matrix.fColumnCount = m_Vector.fRowCount;
		m_Matrix.fRowCount = (file_size / (sizeof(double)* 4)) / m_Matrix.fColumnCount;
		if (m_Matrix.fRowCount - floor(m_Matrix.fRowCount) > 0)
			nRtn = MISS_MATCH_ORDER;
		fclose(matrix);
	}
	else
		nRtn = CANNOT_OPEN_FILE;

	return nRtn;
}

int CMVMul_data_generatorDlg::CountVectorSize()
{
	FILE				*vector;
	long				file_size;

	USES_CONVERSION;
	if (NULL != (vector = fopen(OLE2A(m_strVPath), "rb")))
	{
		fseek(vector, 0, SEEK_END);
		file_size = ftell(vector);

		m_Vector.fRowCount = file_size / (sizeof(double)* 2);
		fclose(vector);
	}
	else
		return CANNOT_OPEN_FILE;
}

#define			BUFFER_SIZE				40

BOOL CMVMul_data_generatorDlg::LoadVector(CString strFileName, LPVECTOR_VALUE lpResult)
{
	BOOL		bRtn = FALSE;
	FILE		*vector;
	int			i;
	double		fRow, fColumn, fReal, fImagnary;
	double		fBuffer[BUFFER_SIZE];
	double		*fReadPtr = NULL;
	int			nReadCount;
	int			nReadIndex;
	long long	nElementIndex = 0;
	size_t		readSize;
	long		file_size;

	USES_CONVERSION;
	if (NULL != (vector = fopen(OLE2A(strFileName), "rb")))
	{

		fseek(vector, 0, SEEK_END);
		file_size = ftell(vector);
		fseek(vector, 0, SEEK_SET);
		
		lpResult->fRowCount = file_size / (sizeof(double)* 2);
		lpResult->pfReal = (double*)malloc(sizeof(double)*lpResult->fRowCount);
		lpResult->pfImaginary = (double*)malloc(sizeof(double)*lpResult->fRowCount);
		if (NULL == lpResult->pfReal || NULL == lpResult->pfImaginary)
			goto FREE_MEMORY_2;

		nElementIndex = 0;
		while (1)
		{
			readSize = fread(fBuffer, sizeof(double), BUFFER_SIZE, vector);
			if (0 == readSize)
				break;

			if (0 != readSize % 2)
				goto FREE_MEMORY_2;

			nReadIndex = 0;
			nReadCount = readSize / 2;
			for (i = 0; i < nReadCount; ++i)
			{
				lpResult->pfReal[nElementIndex] = fBuffer[nReadIndex++];
				lpResult->pfImaginary[nElementIndex++] = fBuffer[nReadIndex++];
			}
		}

		fclose(vector);
	}

	bRtn = TRUE;
	return bRtn;

FREE_MEMORY_2:
	FREE_MEM(lpResult->pfReal);
	FREE_MEM(lpResult->pfImaginary);

	fclose(vector);
	bRtn = FALSE;
	return bRtn;
}

BOOL CMVMul_data_generatorDlg::LoadData()
{
	BOOL		bRtn = FALSE;
	FILE		*matrix, *vector;
	int			i;
	double		fRow, fColumn, fReal, fImagnary;
	double		fBuffer[BUFFER_SIZE];
	double		*fReadPtr = NULL;
	int			nReadCount;
	int			nReadIndex;
	long long	nElementIndex = 0;
	size_t		readSize;

	USES_CONVERSION;
	if (NULL != (matrix = fopen(OLE2A(m_strMPath), "rb")))
	{
		m_Matrix.pfReal = (double*)malloc(sizeof(double)*m_Matrix.fRowCount*m_Matrix.fColumnCount);
		m_Matrix.pfImaginary = (double*)malloc(sizeof(double)*m_Matrix.fRowCount*m_Matrix.fColumnCount);
		m_Matrix.pfRow = (double*)malloc(sizeof(double)*m_Matrix.fRowCount*m_Matrix.fColumnCount);
		m_Matrix.pfColumn = (double*)malloc(sizeof(double)*m_Matrix.fRowCount*m_Matrix.fColumnCount);

		if (NULL == m_Matrix.pfReal || NULL == m_Matrix.pfImaginary || NULL == m_Matrix.pfRow || NULL == m_Matrix.pfReal)
			goto FREE_MEMORY;
		/*{
			FREE_MEM(m_Matrix.pfReal);
			FREE_MEM(m_Matrix.pfImaginary);
			FREE_MEM(m_Matrix.pfRow);
			FREE_MEM(m_Matrix.pfReal);
			fclose(matrix);
			return bRtn;
		}*/
		
		nElementIndex = 0;
		while (1)
		{
			readSize = fread(fBuffer, sizeof(double), BUFFER_SIZE, matrix);
			if (0 == readSize)
				break;

			if (0 != readSize % 4)
				goto FREE_MEMORY;
			/*{
				FREE_MEM(m_Matrix.pfReal);
				FREE_MEM(m_Matrix.pfImaginary);
				FREE_MEM(m_Matrix.pfRow);
				FREE_MEM(m_Matrix.pfReal);
				fclose(matrix);
				return bRtn;
			}*/

			nReadIndex = 0;
			nReadCount = readSize / 4;
			for (i = 0; i < nReadCount ; ++i)
			{
				m_Matrix.pfRow[nElementIndex] = fBuffer[nReadIndex++];
				m_Matrix.pfColumn[nElementIndex] = fBuffer[nReadIndex++];
				m_Matrix.pfReal[nElementIndex] = fBuffer[nReadIndex++];
				m_Matrix.pfImaginary[nElementIndex++] = fBuffer[nReadIndex++];
			}
		}
		fclose(matrix);
	}
	
	if (NULL != (vector = fopen(OLE2A(m_strVPath), "rb")))
	{
		m_Vector.pfReal = (double*)malloc(sizeof(double)*m_Vector.fRowCount);
		m_Vector.pfImaginary = (double*)malloc(sizeof(double)*m_Vector.fRowCount);
		if (NULL == m_Vector.pfReal || NULL == m_Vector.pfImaginary)
			goto FREE_MEMORY;

		nElementIndex = 0;
		while (1)
		{
			readSize = fread(fBuffer, sizeof(double), BUFFER_SIZE, vector);
			if (0 == readSize)
				break;

			if (0 != readSize % 2)
				goto FREE_MEMORY;

			nReadIndex = 0;
			nReadCount = readSize / 2;
			for (i = 0; i < nReadCount; ++i)
			{
				m_Vector.pfReal[nElementIndex] = fBuffer[nReadIndex++];
				m_Vector.pfImaginary[nElementIndex++] = fBuffer[nReadIndex++];
			}
		}

		fclose(vector);
	}

	bRtn = TRUE;
	return bRtn;

FREE_MEMORY:
	FREE_MEM(m_Matrix.pfReal);
	FREE_MEM(m_Matrix.pfImaginary);
	FREE_MEM(m_Matrix.pfRow);
	FREE_MEM(m_Matrix.pfReal);
	FREE_MEM(m_Vector.pfReal);
	FREE_MEM(m_Vector.pfImaginary);

	fclose(matrix);
	fclose(vector);
	bRtn = FALSE;
	return bRtn;
}

BOOL CMVMul_data_generatorDlg::MVMul(LPVECTOR_VALUE lpResult)
{
	BOOL	bRtn = FALSE;
	double	i, j;

	if (0 == m_Matrix.fRowCount || 0 == m_Matrix.fColumnCount || 0 == m_Vector.fRowCount || m_Vector.fRowCount != m_Matrix.fColumnCount)
		return bRtn;

	lpResult->fRowCount = m_Matrix.fRowCount;
	lpResult->pfReal = (double*)malloc(sizeof(double)*lpResult->fRowCount);
	lpResult->pfImaginary = (double*)malloc(sizeof(double)*lpResult->fRowCount);

	if (NULL == lpResult->pfReal || NULL == lpResult->pfImaginary)
	{
		FREE_MEM(lpResult->pfReal);
		FREE_MEM(lpResult->pfImaginary);
		return bRtn;
	}

	for (i = 0; i < m_Matrix.fRowCount; ++i)
	{
		lpResult->pfReal[(int)i] = 0.;
		lpResult->pfImaginary[(int)i] = 0.;
		for (j = 0; j < m_Matrix.fColumnCount; ++j)
		{
			double		fMatrixReal = m_Matrix.pfReal[(int)i*(int)m_Matrix.fColumnCount + (int)j];
			double		fMatrixImaginary = m_Matrix.pfImaginary[(int)i*(int)m_Matrix.fColumnCount + (int)j];
			lpResult->pfReal[(int)i] += fMatrixReal * m_Vector.pfReal[(int)j] - fMatrixImaginary * m_Vector.pfImaginary[(int)j];
			lpResult->pfImaginary[(int)i] += fMatrixReal * m_Vector.pfImaginary[(int)j] + fMatrixImaginary * m_Vector.pfReal[(int)j];
		}
	}

	bRtn = SaveResult(L"vector_output.dat", lpResult);
	return bRtn;
}

void CMVMul_data_generatorDlg::OnNcDestroy()
{
	InitData();
	InitAuditData();
	CDialogEx::OnNcDestroy();

	// TODO: Add your message handler code here
}


BOOL CMVMul_data_generatorDlg::SaveResult(CString strFileName, LPVECTOR_VALUE lpResult)
{
	FILE				*dataFile;
	BOOL				bRtn = FALSE;
	double				i;

	if (NULL == lpResult)
		return bRtn;;

	USES_CONVERSION;
	if (NULL != (dataFile = fopen(OLE2A(strFileName), "wb")))
	{
		for (i = 0; i < lpResult->fRowCount; ++i)
		{
			fwrite(&lpResult->pfReal[(int)i], sizeof(double), 1, dataFile);
			fwrite(&lpResult->pfImaginary[(int)i], sizeof(double), 1, dataFile);
		}
		fclose(dataFile);
		bRtn = TRUE;
	}

	return bRtn;
}

void CMVMul_data_generatorDlg::OnBnClickedButtonAuditGet()
{
	// TODO: Add your control notification handler code here

	TCHAR szFilters[] = _T("Data File (*.dat)|*.dat|All Files (*.*)|*.*||");

	CFileDialog fileDlg(TRUE, _T("dat"), _T("*.dat"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (fileDlg.DoModal() == IDOK)
	{
		m_strSDataPath = fileDlg.GetPathName();

		// Implement opening and reading file in here.

		//Change the window's title to the opened file's title.
		CString fileName = fileDlg.GetFileName();

		CEdit			*pSData = (CEdit*)GetDlgItem(IDC_EDIT_AUDIT_STANDARD);

		pSData->SetWindowText(fileName);
	}
}


void CMVMul_data_generatorDlg::OnBnClickedButtonTargetGet()
{
	// TODO: Add your control notification handler code here
	TCHAR szFilters[] = _T("Data File (*.dat)|*.dat|All Files (*.*)|*.*||");

	CFileDialog fileDlg(TRUE, _T("dat"), _T("*.dat"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (fileDlg.DoModal() == IDOK)
	{
		m_strTDataPath = fileDlg.GetPathName();

		// Implement opening and reading file in here.

		//Change the window's title to the opened file's title.
		CString fileName = fileDlg.GetFileName();

		CEdit			*pTData = (CEdit*)GetDlgItem(IDC_EDIT_AUDIT_TARGET);

		pTData->SetWindowText(fileName);
	}
}


void CMVMul_data_generatorDlg::OnBnClickedButtonResultAudit()
{
	// TODO: Add your control notification handler code here

	AddMsg(L"Start auditing calculation result.");
	InitAuditData();

	if (m_strSDataPath.IsEmpty() || m_strTDataPath.IsEmpty())
	{
		MessageBox(L"Select Audit files first", L"Stop", MB_ICONERROR);
		return;
	}

	if (!LoadVector(m_strSDataPath, &m_VectorAudit))
	{
		MessageBox(L"Can't load Audit file", L"Stop", MB_ICONERROR);
		return;
	}

	if (!LoadVector(m_strTDataPath, &m_VectorAuditTarget))
	{
		MessageBox(L"Can't load Audit target file", L"Stop", MB_ICONERROR);
		InitAuditData();
		return;
	}

	if (m_VectorAudit.fRowCount != m_VectorAuditTarget.fRowCount)
	{
		MessageBox(L"Audit target file size doen't match with audit file", L"Stop", MB_ICONERROR);
		InitAuditData();
		return;
	}

	if (CompareVector(&m_VectorAudit, &m_VectorAuditTarget))
	{
		AddMsg(L"Results are same.");
		MessageBox(L"Results are same.", L"Successed", MB_ICONINFORMATION);
	}
	else
	{
		AddMsg(L"Results are different.");
		MessageBox(L"Results are different.", L"Fail", MB_ICONSTOP);
	}
	
	InitAuditData();
}

BOOL CMVMul_data_generatorDlg::CompareVector(LPVECTOR_VALUE lpSouce, LPVECTOR_VALUE lpTarget)
{
	BOOL			bRtn = FALSE;
	long long		i;
	double			fTolerance = 1e-5;

	for (i = 0; i < lpSouce->fRowCount; ++i)
	{
		if (fabs(lpSouce->pfReal[i] - lpTarget->pfReal[i]) > fTolerance)
			return bRtn;

		if (fabs(lpSouce->pfImaginary[i] - lpTarget->pfImaginary[i]) > fTolerance)
			return bRtn;
	}

	bRtn = TRUE;
	return bRtn;
}

void CMVMul_data_generatorDlg::AddMsg(CString strMsg)
{
	int			nIndex = m_listMsg.InsertString(-1, strMsg);
	m_listMsg.SetCurSel(nIndex);
}