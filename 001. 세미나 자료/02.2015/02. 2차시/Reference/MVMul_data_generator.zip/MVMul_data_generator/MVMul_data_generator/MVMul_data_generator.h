
// MVMul_data_generator.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CMVMul_data_generatorApp:
// See MVMul_data_generator.cpp for the implementation of this class
//

class CMVMul_data_generatorApp : public CWinApp
{
public:
	CMVMul_data_generatorApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CMVMul_data_generatorApp theApp;