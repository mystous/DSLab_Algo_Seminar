
// MVMul_data_generatorDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CMVMul_data_generatorDlg dialog
class CMVMul_data_generatorDlg : public CDialogEx
{
	typedef struct{
		double			fRowCount;
		double			fColumnCount;
		double			*pfRow;
		double			*pfColumn;
		double			*pfReal;
		double			*pfImaginary;
	} MATRIX_VALUE, *LPMATRIX_VALUE;

	typedef struct{
		double			fRowCount;
		double			*pfReal;
		double			*pfImaginary;
	} VECTOR_VALUE, *LPVECTOR_VALUE;

// Construction
public:
	CMVMul_data_generatorDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MVMUL_DATA_GENERATOR_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonGenerate();
private:
	void GenerateMatrix(double fRowSize, double fColumnSize, CString strMatrixFileName, BOOL bMissing);
	void GenerateVector(double fRowSize, CString strVectorFileName, BOOL bMissing);
	void InitData();
	void InitAuditData();
	int CountMatrixSize();
	int CountVectorSize();
	BOOL CompareVector(LPVECTOR_VALUE lpSouce, LPVECTOR_VALUE lpTarget);
	BOOL LoadData();
	BOOL LoadVector(CString strFileName, LPVECTOR_VALUE lpResult);
	BOOL MVMul(LPVECTOR_VALUE lpResult);
	BOOL SaveResult(CString strFileName, LPVECTOR_VALUE lpResult);
	void AddMsg(CString strMsg);
	CString m_strMPath;
	CString m_strVPath;
	CString m_strSDataPath;
	CString m_strTDataPath;
	CString m_strMsg;
	MATRIX_VALUE m_Matrix;
	VECTOR_VALUE m_Vector, m_VectorResult, m_VectorAudit, m_VectorAuditTarget;
public:
	afx_msg void OnBnClickedButtonMInputGet();
	afx_msg void OnBnClickedButtonVInputGet();
	afx_msg void OnBnClickedButtonMvmul();
	afx_msg void OnNcDestroy();
	afx_msg void OnBnClickedButtonAuditGet();
	afx_msg void OnBnClickedButtonTargetGet();
	afx_msg void OnBnClickedButtonResultAudit();
	CListBox m_listMsg;
};
