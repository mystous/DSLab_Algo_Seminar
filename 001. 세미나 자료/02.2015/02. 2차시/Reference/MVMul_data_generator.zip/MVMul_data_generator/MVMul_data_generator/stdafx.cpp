
// stdafx.cpp : source file that includes just the standard includes
// MVMul_data_generator.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


