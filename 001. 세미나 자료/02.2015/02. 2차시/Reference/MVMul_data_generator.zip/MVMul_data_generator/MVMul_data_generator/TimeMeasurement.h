#pragma once

void start_time_measurement();
void end_time_measurement();